# sudoku-dev
smartphone